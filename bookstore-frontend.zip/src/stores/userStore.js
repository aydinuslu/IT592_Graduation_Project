import { defineStore } from 'pinia';
import { useAuthStore } from './authStore';

const API_URL = 'http://localhost:8081/api/users';

export const useUserStore = defineStore('user', {
  state: () => ({
    userInfo: null,
    error: null,
  }),
  actions: {
    async registerUser(userData) {
      try {
        const response = await fetch(`${API_URL}/register`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
          },
          body: JSON.stringify(userData),
        });

        if (!response.ok) {
          throw new Error('Failed to register user');
        }

        const data = await response.json();
        this.userInfo = data;
        this.error = null;
      } catch (error) {
        this.error = error.message;
        this.userInfo = null;
      }
    },

    async getUserById(userId) {
      const authStore = useAuthStore();

      try {
        const response = await fetch(`${API_URL}/${userId}`, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            ...authStore.getAuthHeader(),  // Add Authorization header
          },
        });

        if (!response.ok) {
          throw new Error('Failed to get user');
        }

        const data = await response.json();
        this.userInfo = data;
        this.error = null;
      } catch (error) {
        this.error = error.message;
        this.userInfo = null;
      }
    },
  },
});

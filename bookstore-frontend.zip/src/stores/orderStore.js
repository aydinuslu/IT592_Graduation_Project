import { defineStore } from 'pinia';

export const useOrderStore = defineStore('order', {
  state: () => ({
    orders: [],
    currentOrder: null,
  }),
  actions: {
    async fetchOrders() {
      try {
        const response = await fetch('http://localhost:8084/api/orders', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        if (!response.ok) throw new Error('Failed to fetch orders');
        this.orders = await response.json();
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    },
    async createOrder(orderData) {
      try {
        const response = await fetch('http://localhost:8084/api/orders', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(orderData),
        });
        if (!response.ok) throw new Error('Failed to create order');
        this.currentOrder = await response.json();
      } catch (error) {
        console.error('Error creating order:', error);
      }
    },
    async fetchOrderById(orderId) {
      try {
        const response = await fetch(`http://localhost:8084/api/orders/${orderId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        if (!response.ok) throw new Error('Failed to fetch order');
        this.currentOrder = await response.json();
      } catch (error) {
        console.error('Error fetching order:', error);
      }
    },
  },
});

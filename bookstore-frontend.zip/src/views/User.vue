<template>
  <div class="flex justify-center items-center min-h-screen bg-gray-100">
    <user-form :isEditMode="true" :initialUserData="user" @update-user="updateUser"></user-form>
  </div>
</template>

<script>
import { useUserStore } from '@/stores/userStore';
import UserForm from '@/components/UserForm.vue';

export default {
  components: { UserForm },
  setup() {
    const userStore = useUserStore();
    const user = userStore.userInfo || {};

    const updateUser = async (updatedUser) => {
      await userStore.updateUser(user.id, updatedUser);
    };

    return {
      user,
      updateUser
    };
  }
};
</script>

<style scoped>
/* Tailwind CSS classes used directly in the template */
</style>

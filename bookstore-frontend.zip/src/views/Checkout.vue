<script setup>
import { useCartStore } from '@/stores/cartStore';
import { computed } from 'vue';

const cartStore = useCartStore();

// Access cart from the store
const cart = computed(() => cartStore.cart);
const total = computed(() => cartStore.totalPrice);

// Proceed to checkout or other logic
function proceedToCheckout() {
  if (cart.value && cart.value.length > 0) {
    // Your checkout logic here
  } else {
    console.error("Cart is empty!");
  }
}
</script>

<template>
  <div class="max-w-2xl mx-auto p-4">
    <h1 class="text-3xl font-bold mb-4 text-center">Checkout</h1>

    <div v-if="cart && cart.length" class="bg-white shadow-lg rounded-lg p-6">
      <ul class="divide-y divide-gray-200">
        <li
          v-for="item in cart"
          :key="item.id"
          class="flex justify-between py-4 items-center"
        >
          <div>
            <h2 class="text-lg font-semibold">{{ item.name }}</h2>
            <p class="text-gray-600">Quantity: {{ item.quantity }}</p>
          </div>
          <p class="text-lg font-semibold">${{ (item.price * item.quantity).toFixed(2) }}</p>
        </li>
      </ul>

      <div class="mt-6 text-right">
        <p class="text-2xl font-bold">Total: ${{ total }}</p>
        <button
          @click="proceedToCheckout"
          class="mt-4 px-6 py-3 bg-blue-600 text-white font-semibold rounded-md shadow-sm hover:bg-blue-700 transition-colors"
        >
          Place Order
        </button>
      </div>
    </div>

    <div v-else class="bg-white shadow-lg rounded-lg p-6 text-center">
      <p class="text-lg font-semibold text-gray-700">Your cart is empty.</p>
      <a
        href="/all-products"
        class="mt-4 inline-block px-6 py-3 bg-green-600 text-white font-semibold rounded-md shadow-sm hover:bg-green-700 transition-colors"
      >
        Browse Products
      </a>
    </div>
  </div>
</template>

<template>
  <div class="text-center">
    <h1 class="text-4xl font-bold mb-4">Welcome to the Online Bookstore!</h1>
    <p class="text-xl">Discover your next great read from our collection of books.</p>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>
